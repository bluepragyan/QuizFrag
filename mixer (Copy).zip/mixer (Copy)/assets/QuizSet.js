const quizSetData = [
    {
        "id": 1,
        "title": "Mathematics Essentials",
        "subjects": ["Mathematics"],
        "topics": ["Algebra", "Arithmetic", "Geometry"],
        "difficulty": "Easy",
        "difficultyValue": 2,
        "tags": ["School", "Foundations"],
        "libraryPath": "assets/libraries/math_library.js",
        "filterSettings": {
            "subjects": ["Mathematics"],
            "topics": ["Algebra", "Arithmetic", "Geometry"],
            "difficulties": ["Very Easy", "Easy", "Moderate"],
            "tags": []
        }
    },
    {
        "id": 2,
        "title": "Advanced Calculus Challenge",
        "subjects": ["Mathematics"],
        "topics": ["Calculus"],
        "difficulty": "Hard",
        "difficultyValue": 4,
        "tags": ["University", "Advanced"],
        "libraryPath": "assets/libraries/math_library.js",
        "filterSettings": {
            "subjects": ["Mathematics"],
            "topics": ["Calculus"],
            "difficulties": ["Hard", "Very Hard"],
            "tags": ["Derivatives"]
        }
    },
    {
        "id": 3,
        "title": "Introductory Statistics",
        "subjects": ["Statistics"],
        "topics": ["Descriptive Statistics", "Probability"],
        "difficulty": "Moderate",
        "difficultyValue": 3,
        "tags": ["Data Science", "Basics"],
        "libraryPath": "assets/libraries/stats_library.js",
        "filterSettings": {
            "subjects": ["Statistics"],
            "topics": ["Descriptive Statistics", "Probability"],
            "difficulties": ["Easy", "Moderate"],
            "tags": []
        }
    },
    {
        "id": 4,
        "title": "Statistical Inference Pro",
        "subjects": ["Statistics"],
        "topics": ["Inferential Statistics"],
        "difficulty": "Very Hard",
        "difficultyValue": 5,
        "tags": ["Research", "Advanced"],
        "libraryPath": "assets/libraries/stats_library.js",
        "filterSettings": {
            "subjects": ["Statistics"],
            "topics": ["Inferential Statistics"],
            "difficulties": ["Hard", "Very Hard"],
            "tags": ["Hypothesis Testing"]
        }
    },
    {
        "id": 5,
        "title": "Master Collection: All Subjects",
        "subjects": ["Mathematics", "Statistics"],
        "topics": ["All Topics"],
        "difficulty": "Mixed",
        "difficultyValue": 3,
        "tags": ["Comprehensive", "Full Access"],
        "libraryPath": "ALL",
        "filterSettings": {
            "subjects": [],
            "topics": [],
            "difficulties": [],
            "tags": []
        }
    }
];
