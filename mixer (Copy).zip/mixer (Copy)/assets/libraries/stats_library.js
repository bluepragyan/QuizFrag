const statsLibraryData = [
    {
        "id": "stats_001",
        "subject": "Statistics",
        "topic": "Descriptive Statistics",
        "difficulty": "Easy",
        "tags": ["Mean", "Basics"],
        "type": "mcq",
        "question": {
            "text": "What is the mean of the data set: 2, 4, 6, 8, 10?",
            "image": null
        },
        "options": [
            { "id": 0, "text": "4", "image": null },
            { "id": 1, "text": "6", "image": null },
            { "id": 2, "text": "8", "image": null },
            { "id": 3, "text": "5", "image": null }
        ],
        "answer": {
            "correct_option": 1,
            "explanation": "Sum of values = 2+4+6+8+10 = 30. Mean = 30 / 5 = 6.",
            "hint": "Add all the numbers together and divide by the count of numbers."
        },
        "reference": "Intro to Stats"
    },
    {
        "id": "stats_002",
        "subject": "Statistics",
        "topic": "Probability",
        "difficulty": "Moderate",
        "tags": ["Normal Distribution", "Z-Score"],
        "type": "numerical",
        "question": {
            "text": "In a standard normal distribution, what is the approximate Z-score for the 95th percentile?",
            "image": null
        },
        "answer": {
            "value": 1.645,
            "precision": 3,
            "range": {
                "min": 1.64,
                "max": 1.65
            },
            "explanation": "Looking at the Z-table, the 95th percentile corresponds to a Z-score of approximately 1.645.",
            "hint": "Check a standard normal distribution table or use the 68-95-99.7 rule as a starting point."
        },
        "reference": "Statistical Tables"
    },
    {
        "id": "stats_003",
        "subject": "Statistics",
        "topic": "Inferential Statistics",
        "difficulty": "Hard",
        "tags": ["Hypothesis Testing", "P-Value"],
        "type": "msq",
        "question": {
            "text": "Which of the following are true about the p-value?",
            "image": null
        },
        "options": [
            { "id": 0, "text": "It is the probability of observing the data if the null hypothesis is true.", "image": null },
            { "id": 1, "text": "A small p-value (typically ≤ 0.05) indicates strong evidence against the null hypothesis.", "image": null },
            { "id": 2, "text": "It is the probability that the null hypothesis is true.", "image": null },
            { "id": 3, "text": "It is the probability that the alternative hypothesis is true.", "image": null }
        ],
        "answer": {
            "correct_options": [0, 1],
            "explanation": "The p-value is the probability of the data given H0, not the probability of H0 or H1 itself.",
            "hint": "Understand the conditional nature of the p-value."
        },
        "reference": "Advanced Statistics"
    }
];