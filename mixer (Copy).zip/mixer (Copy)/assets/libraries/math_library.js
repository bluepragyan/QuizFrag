const mathLibraryData = [
    {
        "id": "math_001",
        "subject": "Mathematics",
        "topic": "Algebra",
        "difficulty": "Easy",
        "tags": ["Linear Equations", "Foundations"],
        "type": "mcq",
        "question": {
            "text": "Solve for x: 2x + 10 = 20",
            "image": null
        },
        "options": [
            { "id": 0, "text": "5", "image": null },
            { "id": 1, "text": "10", "image": null },
            { "id": 2, "text": "15", "image": null },
            { "id": 3, "text": "20", "image": null }
        ],
        "answer": {
            "correct_option": 0,
            "explanation": "Subtract 10 from both sides: 2x = 10. Then divide by 2: x = 5.",
            "hint": "Try to isolate x on one side of the equation."
        },
        "reference": "Algebra Basics Vol 1"
    },
    {
        "id": "math_002",
        "subject": "Mathematics",
        "topic": "Calculus",
        "difficulty": "Hard",
        "tags": ["Derivatives", "Power Rule"],
        "type": "msq",
        "question": {
            "text": "Which of the following are correct derivatives?",
            "image": "assets/images/calculus_deriv.png"
        },
        "options": [
            { "id": 0, "text": "d/dx (x^2) = 2x", "image": null },
            { "id": 1, "text": "d/dx (sin x) = cos x", "image": null },
            { "id": 2, "text": "d/dx (e^x) = xe^(x-1)", "image": null },
            { "id": 3, "text": "d/dx (ln x) = 1/x", "image": null }
        ],
        "answer": {
            "correct_options": [0, 1, 3],
            "explanation": "The derivative of e^x is e^x, not xe^(x-1). All others are standard derivatives.",
            "hint": "Recall the rules for transcendental functions."
        },
        "reference": "Thomas' Calculus"
    },
    {
        "id": "math_003",
        "subject": "Mathematics",
        "topic": "Geometry",
        "difficulty": "Moderate",
        "tags": ["Area", "Circles"],
        "type": "numerical",
        "question": {
            "text": "Calculate the area of a circle with a radius of 5 units. (Use π = 3.14159)",
            "image": null
        },
        "answer": {
            "value": 78.53975,
            "precision": 4,
            "range": {
                "min": 78.53,
                "max": 78.55
            },
            "explanation": "Area = πr^2 = 3.14159 * 5^2 = 3.14159 * 25 = 78.53975.",
            "hint": "The formula for the area of a circle is π multiplied by the square of the radius."
        },
        "reference": "Euclidean Geometry"
    },
    {
        "id": "math_004",
        "subject": "Mathematics",
        "topic": "Arithmetic",
        "difficulty": "Very Easy",
        "tags": ["Addition"],
        "type": "fib",
        "question": {
            "text": "The result of 15 + 27 is ________.",
            "image": null
        },
        "answer": {
            "accepted_values": ["42"],
            "explanation": "15 plus 27 equals 42.",
            "hint": "Break it down: 10+20=30, 5+7=12, 30+12=42."
        },
        "reference": "Primary Math"
    }
];