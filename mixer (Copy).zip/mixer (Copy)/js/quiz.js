document.addEventListener('DOMContentLoaded', () => {
    // --- State Management ---
    let currentQuizSet = null;
    let filteredQuestions = [];
    let currentQuestionIndex = 0;
    let userAnswers = {}; // Store answers by question ID
    let checkedQuestions = new Set(); // Track which questions have been "checked"
    let startTime = null;
    let timerInterval = null;
    let totalSeconds = 0;

    // --- Visual Rendering Engine ---
    const VisualRenderer = {
        render(text, container) {
            if (!text) {
                container.innerHTML = '';
                return;
            }

            // Detect XML
            const mathMatch = text.match(/<math>[\s\S]*?<\/math>/g);
            const graphMatch = text.match(/<graphml>[\s\S]*?<\/graphml>/g);
            const vectorMatch = text.match(/<vector>[\s\S]*?<\/vector>/g);

            let cleanText = text;
            
            // Handle MathML (native browser support)
            if (mathMatch) {
                mathMatch.forEach(m => {
                    cleanText = cleanText.replace(m, `<div class="mathml-container">${m}</div>`);
                });
            }
            
            // Basic text rendering
            container.innerHTML = cleanText;

            // Handle Graphs and Vectors on Canvas
            if (graphMatch || vectorMatch) {
                this.addCanvasToggle(container, graphMatch, vectorMatch);
            }
        },

        addCanvasToggle(container, graphs, vectors) {
            const btn = document.createElement('button');
            btn.className = 'visual-toggle';
            btn.innerHTML = `<span>Representations</span><span class="arrow-icon">▾</span>`;
            
            const canvasContainer = document.createElement('div');
            canvasContainer.className = 'canvas-container';
            
            const canvas = document.createElement('canvas');
            canvas.width = 800;
            canvas.height = 400;
            canvasContainer.appendChild(canvas);

            btn.onclick = (e) => {
                e.stopPropagation();
                const isExpanded = canvasContainer.classList.toggle('expanded');
                btn.classList.toggle('expanded', isExpanded);
                if (isExpanded) {
                    this.drawOnCanvas(canvas, graphs, vectors);
                }
            };

            container.appendChild(btn);
            container.insertAdjacentElement('afterend', canvasContainer);
        },

        drawOnCanvas(canvas, graphs, vectors) {
            const ctx = canvas.getContext('2d');
            ctx.clearRect(0, 0, canvas.width, canvas.height);
            ctx.strokeStyle = '#3b82f6';
            ctx.fillStyle = '#3b82f6';
            ctx.font = '14px Inter';

            if (graphs) {
                graphs.forEach(xml => {
                    // Primitive GraphML-like rendering
                    ctx.beginPath();
                    ctx.moveTo(100, 100); ctx.lineTo(300, 100);
                    ctx.moveTo(300, 100); ctx.lineTo(200, 250);
                    ctx.moveTo(200, 250); ctx.lineTo(100, 100);
                    ctx.stroke();
                    
                    [ [100,100], [300,100], [200,250] ].forEach((p, i) => {
                        ctx.beginPath();
                        ctx.arc(p[0], p[1], 15, 0, Math.PI*2);
                        ctx.fill();
                        ctx.fillStyle = 'white';
                        ctx.fillText(`N${i}`, p[0]-8, p[1]+5);
                        ctx.fillStyle = '#3b82f6';
                    });
                });
            }

            if (vectors) {
                vectors.forEach(xml => {
                    ctx.strokeStyle = '#f59e0b';
                    ctx.lineWidth = 3;
                    ctx.beginPath();
                    ctx.moveTo(400, 50);
                    ctx.lineTo(500, 350);
                    ctx.lineTo(700, 200);
                    ctx.stroke();
                });
            }
        }
    };

    // --- Sliding Window Cache Manager ---
    const QuestionCacheManager = {
        fullLibrary: [], // Store all raw question data
        activeWindow: new Map(), // Map<index, questionData>
        
        setLibrary(data) {
            this.fullLibrary = data;
            this.activeWindow.clear();
        },

        getQuestion(index) {
            if (this.activeWindow.has(index)) {
                return this.activeWindow.get(index);
            }

            // Fetch and cache
            const data = this.fullLibrary[index];
            this.activeWindow.set(index, data);

            // Maintain sliding window (5 prev, 1 current, 5 next)
            const minIdx = index - 5;
            const maxIdx = index + 5;

            for (let [idx, cachedData] of this.activeWindow) {
                if (idx < minIdx || idx > maxIdx) {
                    this.activeWindow.delete(idx);
                }
            }

            return data;
        },

        // Mock "real-time" partial read
        async loadFromFile(file) {
            return new Promise((resolve, reject) => {
                const reader = new FileReader();
                reader.onload = (e) => {
                    try {
                        const json = JSON.parse(e.target.result);
                        // If it's a full library file
                        if (Array.isArray(json)) resolve(json);
                        // If it's a QuizSet file with embedded questions
                        else if (json.quizSets && json.quizSets[0].embeddedQuestions) {
                            resolve(json.quizSets[0].embeddedQuestions);
                        } else if (json.embeddedQuestions) {
                            resolve(json.embeddedQuestions);
                        } else {
                            resolve([]);
                        }
                    } catch (err) {
                        reject(err);
                    }
                };
                reader.readAsText(file);
            });
        }
    };

    // --- UI Elements ---
    const configSection = document.getElementById('quiz-config');
    const activeSection = document.getElementById('quiz-active');
    const resultsSection = document.getElementById('quiz-results');
    
    const configTitle = document.getElementById('config-quiz-title');
    const questionCountInput = document.getElementById('question-count');
    const timeLimitInput = document.getElementById('time-limit');
    const showScoreCheckbox = document.getElementById('show-score');
    const startBtn = document.getElementById('start-quiz-btn');
    const availableHint = document.getElementById('available-questions-hint');

    const qNumberLabel = document.getElementById('question-number');
    const qDifficultyLabel = document.getElementById('q-difficulty');
    const qText = document.getElementById('q-text');
    const optionsContainer = document.getElementById('options-container');
    const qImageContainer = document.getElementById('q-image-container');
    const qImage = document.getElementById('q-image');

    const prevBtn = document.getElementById('prev-btn');
    const nextBtn = document.getElementById('next-btn');
    const checkBtn = document.getElementById('check-btn');
    const finishBtn = document.getElementById('finish-btn');
    const exitBtn = document.getElementById('exit-quiz');
    const timerDisplay = document.getElementById('timer-display');

    const infoPanel = document.getElementById('info-panel');
    const togglePanelBtn = document.getElementById('toggle-panel');
    const tabLinks = document.querySelectorAll('.tab-link');
    const tabPanes = document.querySelectorAll('.tab-pane');

    // --- Audio Engine ---
    const AudioEngine = {
        ctx: null,
        bgMusic: document.getElementById('bg-music'),
        isMusicOn: true,

        init() {
            try {
                this.ctx = new (window.AudioContext || window.webkitAudioContext)();
            } catch (e) {
                console.error("Web Audio API not supported");
            }
            this.setupBgMusic();
        },

        setupBgMusic() {
            if (!this.bgMusic) return;
            this.bgMusic.volume = 0.3;
            // Listen for timeupdate to loop at 1:05 (65 seconds)
            this.bgMusic.addEventListener('timeupdate', () => {
                if (this.bgMusic.currentTime >= 65) {
                    this.bgMusic.currentTime = 0;
                    this.bgMusic.play();
                }
            });
        },

        toggleMusic() {
            this.isMusicOn = !this.isMusicOn;
            const btn = document.getElementById('toggle-music');
            if (this.isMusicOn) {
                this.bgMusic.play().catch(e => console.log("User interaction needed"));
                btn.textContent = "🎵 On";
            } else {
                this.bgMusic.pause();
                btn.textContent = "🎵 Off";
            }
        },

        playChord(type) {
            if (!this.ctx) return;
            if (this.ctx.state === 'suspended') this.ctx.resume();

            const frequencies = type === 'correct' 
                ? [164.81, 196.00, 246.94, 293.66, 369.99] // E3, G3, B3, D4, F#4 (E min 7 add 9)
                : [261.63, 311.13, 369.99]; // C4, Eb4, Gb4 (C diminished)

            const now = this.ctx.currentTime;
            const duration = 1.2;

            frequencies.forEach(freq => {
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();

                osc.type = 'triangle';
                osc.frequency.setValueAtTime(freq, now);

                gain.gain.setValueAtTime(0.1, now);
                gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

                osc.connect(gain);
                gain.connect(this.ctx.destination);

                osc.start(now);
                osc.stop(now + duration);
            });
        }
    };

    // Library mapping (from assets/libraries/*.js)
    const libraryMap = {
        'assets/libraries/math_library.js': typeof mathLibraryData !== 'undefined' ? mathLibraryData : [],
        'assets/libraries/stats_library.js': typeof statsLibraryData !== 'undefined' ? statsLibraryData : []
    };

    // --- Initial Setup ---
    function init() {
        AudioEngine.init();
        const urlParams = new URLSearchParams(window.location.search);
        const quizId = urlParams.get('id'); // ID could be string for custom
        const source = urlParams.get('source');

        if (source === 'custom') {
            loadCustomQuizSet(quizId);
        } else {
            if (typeof quizSetData === 'undefined') {
                window.location.href = 'playquiz.html';
                return;
            }
            currentQuizSet = quizSetData.find(q => q.id == quizId);
        }

        if (!currentQuizSet) {
            window.location.href = 'playquiz.html';
            return;
        }

        configTitle.textContent = currentQuizSet.title;
        prepareQuestions();
        setupEventListeners();
    }

    function loadCustomQuizSet(id) {
        const customLibs = JSON.parse(localStorage.getItem('custom_quiz_libraries') || '[]');
        for (const lib of customLibs) {
            const found = lib.data.quizSets.find(s => s.id == id);
            if (found) {
                currentQuizSet = found;
                return;
            }
        }
    }

    function prepareQuestions() {
        let rawLibrary = [];
        
        if (currentQuizSet.libraryPath === 'EMBEDDED') {
            // Priority: use the embedded questions directly from the set
            rawLibrary = currentQuizSet.embeddedQuestions || [];
            // If they are too large for localStorage, we might have put them in sessionStorage
            if (rawLibrary.length === 0) {
                const temp = sessionStorage.getItem('temp_custom_questions');
                if (temp) rawLibrary = JSON.parse(temp);
            }
        } else if (currentQuizSet.libraryPath === 'ALL') {
            Object.values(libraryMap).forEach(lib => {
                rawLibrary = rawLibrary.concat(lib);
            });
        } else {
            rawLibrary = libraryMap[currentQuizSet.libraryPath] || [];
        }

        const settings = currentQuizSet.filterSettings;

        filteredQuestions = rawLibrary.filter(q => {
            const matchSubject = settings.subjects.length === 0 || settings.subjects.includes(q.subject);
            const matchTopic = settings.topics.length === 0 || settings.topics.includes(q.topic);
            const matchDifficulty = settings.difficulties.length === 0 || settings.difficulties.includes(q.difficulty);
            const matchTags = settings.tags.length === 0 || (q.tags && q.tags.some(t => settings.tags.includes(t)));

            return matchSubject && matchTopic && matchDifficulty && matchTags;
        });

        filteredQuestions.sort(() => Math.random() - 0.5);
        
        // Initialize Cache Manager with filtered set
        QuestionCacheManager.setLibrary(filteredQuestions);

        availableHint.textContent = `Available: ${filteredQuestions.length}`;
        questionCountInput.max = filteredQuestions.length;
        if (parseInt(questionCountInput.value) > filteredQuestions.length) {
            questionCountInput.value = filteredQuestions.length;
        }
    }

    // --- Quiz Logic ---
    function startQuiz() {
        const count = Math.min(parseInt(questionCountInput.value), filteredQuestions.length);
        // Trim the filtered list and update cache manager
        filteredQuestions = filteredQuestions.slice(0, count);
        QuestionCacheManager.setLibrary(filteredQuestions);

        configSection.classList.add('hidden');
        activeSection.classList.remove('hidden');
        
        if (AudioEngine.isMusicOn) {
            AudioEngine.bgMusic.play().catch(e => console.log("Music play blocked until user interaction"));
        }
        
        startTimer();
        displayQuestion();
    }

    function displayQuestion() {
        const q = QuestionCacheManager.getQuestion(currentQuestionIndex);
        const isChecked = checkedQuestions.has(q.id);

        qNumberLabel.textContent = `Question ${currentQuestionIndex + 1} of ${filteredQuestions.length}`;
        qDifficultyLabel.textContent = q.difficulty;
        qDifficultyLabel.className = `difficulty-tag diff-${q.difficulty.toLowerCase().replace(' ', '-')}`;

        VisualRenderer.render(q.question.text, qText);
        
        if (q.question.image) {
            qImage.src = q.question.image;
            qImageContainer.classList.remove('hidden');
        } else {
            qImageContainer.classList.add('hidden');
        }

        renderInputArea(q, isChecked);
        updateInfoPanel(q, isChecked);

        prevBtn.disabled = currentQuestionIndex === 0;
        if (currentQuestionIndex === filteredQuestions.length - 1) {
            nextBtn.classList.add('hidden');
            finishBtn.classList.remove('hidden');
        } else {
            nextBtn.classList.remove('hidden');
            finishBtn.classList.add('hidden');
        }

        checkBtn.disabled = isChecked;
    }

    function renderInputArea(q, isChecked) {
        optionsContainer.innerHTML = '';
        const savedAnswer = userAnswers[q.id];

        if (q.type === 'mcq' || q.type === 'msq') {
            q.options.forEach(opt => {
                const div = document.createElement('div');
                div.className = 'option-item';
                if (isChecked) {
                    const isCorrect = q.type === 'mcq' ? 
                        opt.id === q.answer.correct_option : 
                        q.answer.correct_options.includes(opt.id);
                    
                    const isSelected = q.type === 'mcq' ? 
                        savedAnswer === opt.id : 
                        (savedAnswer || []).includes(opt.id);

                    if (isCorrect) div.classList.add('correct');
                    else if (isSelected) div.classList.add('wrong');
                } else {
                    const isSelected = q.type === 'mcq' ? 
                        savedAnswer === opt.id : 
                        (savedAnswer || []).includes(opt.id);
                    if (isSelected) div.classList.add('selected');
                }

                const prefix = document.createElement('span');
                prefix.className = 'option-prefix';
                prefix.textContent = String.fromCharCode(65 + opt.id);
                
                const textSpan = document.createElement('span');
                textSpan.className = 'option-text';
                VisualRenderer.render(opt.text, textSpan);

                div.appendChild(prefix);
                div.appendChild(textSpan);

                if (!isChecked) {
                    div.onclick = () => selectOption(q, opt.id);
                }
                optionsContainer.appendChild(div);
            });
        } else if (q.type === 'fib' || q.type === 'numerical') {
            const input = document.createElement('input');
            input.type = q.type === 'numerical' ? 'number' : 'text';
            input.className = 'quiz-input';
            input.placeholder = 'Type your answer...';
            input.value = savedAnswer || '';
            input.disabled = isChecked;

            if (isChecked) {
                const correct = checkCorrectness(q, savedAnswer);
                input.style.borderColor = correct ? '#10b981' : '#ef4444';
                input.style.backgroundColor = correct ? 'rgba(16, 185, 129, 0.1)' : 'rgba(239, 68, 68, 0.1)';
            }

            input.onchange = (e) => userAnswers[q.id] = e.target.value;
            optionsContainer.appendChild(input);
        }
    }

    function selectOption(q, optId) {
        if (q.type === 'mcq') {
            userAnswers[q.id] = optId;
        } else {
            if (!userAnswers[q.id]) userAnswers[q.id] = [];
            const idx = userAnswers[q.id].indexOf(optId);
            if (idx > -1) userAnswers[q.id].splice(idx, 1);
            else userAnswers[q.id].push(optId);
        }
        displayQuestion();
    }

    function checkAnswer() {
        const q = QuestionCacheManager.getQuestion(currentQuestionIndex);
        checkedQuestions.add(q.id);

        const isCorrect = checkCorrectness(q, userAnswers[q.id]);
        AudioEngine.playChord(isCorrect ? 'correct' : 'wrong');

        displayQuestion();
        infoPanel.classList.remove('collapsed');
        document.querySelector('[data-tab="explanation"]').click();
    }

    function checkCorrectness(q, answer) {
        if (!answer && answer !== 0) return false;

        if (q.type === 'mcq') return answer === q.answer.correct_option;
        if (q.type === 'msq') {
            if (!Array.isArray(answer)) return false;
            return answer.length === q.answer.correct_options.length && 
                   answer.every(val => q.answer.correct_options.includes(val));
        }
        if (q.type === 'fib') {
            return q.answer.accepted_values.some(v => v.toLowerCase().trim() === answer.toLowerCase().trim());
        }
        if (q.type === 'numerical') {
            const val = parseFloat(answer);
            return val >= q.answer.range.min && val <= q.answer.range.max;
        }
        return false;
    }

    function updateInfoPanel(q, isChecked) {
        const hintPane = document.getElementById('pane-hint');
        const refPane = document.getElementById('pane-reference');
        const explPane = document.getElementById('pane-explanation');

        VisualRenderer.render(q.answer.hint || 'No hint available.', hintPane);
        VisualRenderer.render(q.reference || 'No reference available.', refPane);
        
        if (isChecked) {
            VisualRenderer.render(q.answer.explanation, explPane);
        } else {
            explPane.textContent = 'Check your answer to see the explanation.';
        }
    }

    // --- Timer ---
    function startTimer() {
        startTime = Date.now();
        const limitMin = parseInt(timeLimitInput.value);
        
        if (limitMin > 0) {
            timerDisplay.classList.remove('hidden');
            let remaining = limitMin * 60;
            updateTimerUI(remaining);

            timerInterval = setInterval(() => {
                remaining--;
                updateTimerUI(remaining);
                if (remaining <= 0) {
                    clearInterval(timerInterval);
                    finishQuiz();
                }
            }, 1000);
        }
    }

    function updateTimerUI(seconds) {
        const m = Math.floor(seconds / 60);
        const s = seconds % 60;
        timerDisplay.textContent = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
        if (seconds < 60) timerDisplay.style.color = '#ef4444';
    }

    // --- Finishing ---
    function finishQuiz() {
        clearInterval(timerInterval);
        const endTime = Date.now();
        totalSeconds = Math.floor((endTime - startTime) / 1000);

        activeSection.classList.add('hidden');
        resultsSection.classList.remove('hidden');
        timerDisplay.classList.add('hidden');

        calculateResults();
    }

    function calculateResults() {
        let correctCount = 0;
        filteredQuestions.forEach((qMeta, idx) => {
            const q = QuestionCacheManager.getQuestion(idx);
            if (checkCorrectness(q, userAnswers[q.id])) {
                correctCount++;
            }
        });

        const total = filteredQuestions.length;
        const percent = Math.round((correctCount / total) * 100);

        if (showScoreCheckbox.checked) {
            document.getElementById('final-score').textContent = `${correctCount} / ${total}`;
            document.getElementById('score-percentage').textContent = `${percent}%`;
        } else {
            document.getElementById('final-score').textContent = `Completed!`;
            document.getElementById('score-percentage').textContent = `Review your performance.`;
        }

        document.getElementById('stat-total').textContent = total;
        document.getElementById('stat-correct').textContent = correctCount;
        document.getElementById('stat-wrong').textContent = total - correctCount;
        
        const m = Math.floor(totalSeconds / 60);
        const s = totalSeconds % 60;
        document.getElementById('stat-time').textContent = `${m}m ${s}s`;
    }

    // --- Events ---
    function setupEventListeners() {
        startBtn.onclick = startQuiz;
        
        document.getElementById('toggle-music').onclick = () => AudioEngine.toggleMusic();

        prevBtn.onclick = () => {
            if (currentQuestionIndex > 0) {
                currentQuestionIndex--;
                displayQuestion();
            }
        };

        nextBtn.onclick = () => {
            if (currentQuestionIndex < filteredQuestions.length - 1) {
                currentQuestionIndex++;
                displayQuestion();
            }
        };

        checkBtn.onclick = checkAnswer;
        finishBtn.onclick = finishQuiz;
        exitBtn.onclick = () => {
            if (confirm('Are you sure you want to exit? Your progress will be lost.')) {
                window.location.href = 'playquiz.html';
            }
        };
        
        const restartBtn = document.getElementById('restart-btn');
        if (restartBtn) restartBtn.onclick = () => window.location.href = 'playquiz.html';

        togglePanelBtn.onclick = () => infoPanel.classList.toggle('collapsed');

        tabLinks.forEach(link => {
            link.onclick = () => {
                tabLinks.forEach(l => l.classList.remove('active'));
                tabPanes.forEach(p => p.classList.remove('active'));
                
                link.classList.add('active');
                document.getElementById(`pane-${link.dataset.tab}`).classList.add('active');
            };
        });
    }

    init();
});
