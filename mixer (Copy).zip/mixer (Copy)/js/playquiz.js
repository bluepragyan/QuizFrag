document.addEventListener('DOMContentLoaded', () => {
    const quizList = document.getElementById('quiz-list');
    const emptyState = document.getElementById('empty-state');
    const subjectFilters = document.getElementById('subject-filters');
    const topicFilters = document.getElementById('topic-filters');
    const minDiffInput = document.getElementById('min-difficulty');
    const maxDiffInput = document.getElementById('max-difficulty');
    const minDiffLabel = document.getElementById('min-diff-label');
    const maxDiffLabel = document.getElementById('max-diff-label');

    let allQuizzes = [];
    let activeSubjects = new Set();
    let activeTopics = new Set();

    const difficultyMap = {
        1: "Very Easy",
        2: "Easy",
        3: "Moderate",
        4: "Hard",
        5: "Very Hard"
    };

    const diffClasses = {
        "Very Easy": "diff-very-easy",
        "Easy": "diff-easy",
        "Moderate": "diff-moderate",
        "Hard": "diff-hard",
        "Very Hard": "diff-very-hard"
    };

    async function fetchQuizzes() {
        try {
            // Using global quizSetData from assets/QuizSet.js
            if (typeof quizSetData === 'undefined') {
                throw new Error('quizSetData is not defined. Check if assets/QuizSet.js is loaded.');
            }
            
            allQuizzes = quizSetData;
            
            if (allQuizzes.length === 0) {
                showEmptyState("The quiz library is currently empty.");
            } else {
                initFilters();
                renderQuizzes();
            }
        } catch (error) {
            console.error('Error loading quizzes:', error);
            showEmptyState(`Failed to load quiz sets: ${error.message}`);
        }
    }

    function initFilters() {
        const subjects = new Set();
        const topics = new Set();

        allQuizzes.forEach(quiz => {
            if (quiz.subjects) quiz.subjects.forEach(s => subjects.add(s));
            if (quiz.topics) quiz.topics.forEach(t => topics.add(t));
        });

        renderFilterChips(subjectFilters, Array.from(subjects), 'subject');
        renderFilterChips(topicFilters, Array.from(topics), 'topic');
    }

    function renderFilterChips(container, items, type) {
        container.innerHTML = '';
        items.sort().forEach(item => {
            const label = document.createElement('label');
            label.className = 'filter-chip';
            label.innerHTML = `
                <input type="checkbox" value="${item}" data-type="${type}">
                <span>${item}</span>
            `;
            
            label.querySelector('input').addEventListener('change', (e) => {
                if (e.target.checked) {
                    label.classList.add('active');
                    if (type === 'subject') activeSubjects.add(item);
                    else activeTopics.add(item);
                } else {
                    label.classList.remove('active');
                    if (type === 'subject') activeSubjects.delete(item);
                    else activeTopics.delete(item);
                }
                renderQuizzes();
            });
            
            container.appendChild(label);
        });
    }

    function renderQuizzes() {
        const filtered = allQuizzes.filter(quiz => {
            const minDiff = parseInt(minDiffInput.value);
            const maxDiff = parseInt(maxDiffInput.value);
            
            const matchesDifficulty = (quiz.difficultyValue || 0) >= minDiff && (quiz.difficultyValue || 0) <= maxDiff;
            const matchesSubject = activeSubjects.size === 0 || (quiz.subjects && quiz.subjects.some(s => activeSubjects.has(s)));
            const matchesTopic = activeTopics.size === 0 || (quiz.topics && quiz.topics.some(t => activeTopics.has(t)));
            
            return matchesDifficulty && matchesSubject && matchesTopic;
        });

        quizList.innerHTML = '';
        
        if (filtered.length === 0) {
            showEmptyState("No quiz sets match your current filters.");
        } else {
            emptyState.classList.add('hidden');
            filtered.forEach(quiz => {
                const card = createQuizCard(quiz);
                quizList.appendChild(card);
            });
        }
    }

    function createQuizCard(quiz) {
        const card = document.createElement('div');
        card.className = 'quiz-card';
        card.style.cursor = 'pointer';

        const subjectsText = (quiz.subjects || []).join(', ');
        const topicsText = (quiz.topics || []).join(', ');

        card.innerHTML = `
            <h3>${quiz.title || 'Untitled Quiz'}</h3>
            <div class="quiz-info">
                <div class="info-item">
                    <span class="info-label">Subject:</span> 
                    ${renderTruncatedText(subjectsText, 30)}
                </div>
                <div class="info-item">
                    <span class="info-label">Topic:</span> 
                    ${renderTruncatedText(topicsText, 40)}
                </div>
                <div class="info-item">
                    <span class="info-label">Difficulty:</span> 
                    <span class="difficulty-badge ${diffClasses[quiz.difficulty] || ''}">${quiz.difficulty || 'Unknown'}</span>
                </div>
            </div>
            <div class="tags-container">
                ${(quiz.tags || []).map(tag => `<span class="tag">${tag}</span>`).join('')}
                <div class="infobox">${(quiz.tags || []).join(', ')}</div>
            </div>
        `;

        card.addEventListener('click', () => {
            window.location.href = `quiz.html?id=${quiz.id}`;
        });
        
        const tagsContainer = card.querySelector('.tags-container');
        tagsContainer.addEventListener('mouseenter', () => {
            if (tagsContainer.scrollHeight > tagsContainer.clientHeight) {
                const infobox = tagsContainer.querySelector('.infobox');
                if (infobox) {
                    infobox.style.visibility = 'visible';
                    infobox.style.opacity = '1';
                }
            }
        });
        tagsContainer.addEventListener('mouseleave', () => {
            const infobox = tagsContainer.querySelector('.infobox');
            if (infobox) {
                infobox.style.visibility = 'hidden';
                infobox.style.opacity = '0';
            }
        });

        return card;
    }

    function renderTruncatedText(text, limit) {
        if (text.length <= limit) return text;
        
        return `
            <div class="truncate-container">
                <span class="truncate-text">${text.substring(0, limit)}...</span>
                <div class="infobox">${text}</div>
            </div>
        `;
    }

    function showEmptyState(message) {
        quizList.innerHTML = '';
        if (message) {
            const p = emptyState.querySelector('p');
            if (p) p.textContent = message;
        }
        emptyState.classList.remove('hidden');
    }

    // Difficulty Range Listeners
    minDiffInput.addEventListener('input', () => {
        if (parseInt(minDiffInput.value) > parseInt(maxDiffInput.value)) {
            maxDiffInput.value = minDiffInput.value;
        }
        updateDiffLabels();
        renderQuizzes();
    });

    maxDiffInput.addEventListener('input', () => {
        if (parseInt(maxDiffInput.value) < parseInt(minDiffInput.value)) {
            minDiffInput.value = maxDiffInput.value;
        }
        updateDiffLabels();
        renderQuizzes();
    });

    function updateDiffLabels() {
        minDiffLabel.textContent = difficultyMap[minDiffInput.value];
        maxDiffLabel.textContent = difficultyMap[maxDiffInput.value];
    }

    fetchQuizzes();
});
