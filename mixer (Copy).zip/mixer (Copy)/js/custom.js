document.addEventListener('DOMContentLoaded', () => {
    const importInput = document.getElementById('import-json');
    const librariesList = document.getElementById('libraries-list');
    const quizList = document.getElementById('quiz-list');
    const loadDemoBtn = document.getElementById('load-demo-btn');

    let customLibraries = JSON.parse(localStorage.getItem('custom_quiz_libraries') || '[]');

    loadDemoBtn.addEventListener('click', async () => {
        try {
            const response = await fetch('assets/guide_template.json');
            const data = await response.json();
            
            // Check if already loaded to prevent duplicates
            if (customLibraries.some(lib => lib.name === 'Guide Template (Demo)')) {
                alert('Demo is already in your manager.');
                return;
            }

            const demoLib = {
                name: 'Guide Template (Demo)',
                active: true,
                data: data,
                importDate: new Date().toISOString()
            };

            customLibraries.unshift(demoLib); // Put it at the top
            saveLibraries();
        } catch (err) {
            console.error('Error loading demo:', err);
            alert('Note: Loading the demo directly requires a local server. You can still download and import it manually.');
        }
    });

    function saveLibraries() {
        localStorage.setItem('custom_quiz_libraries', JSON.stringify(customLibraries));
        renderLibraries();
        renderQuizSets();
    }

    function renderLibraries() {
        librariesList.innerHTML = '';
        if (customLibraries.length === 0) {
            librariesList.innerHTML = '<p class="text-muted" style="padding: 1rem 0;">No custom libraries imported yet.</p>';
            return;
        }

        customLibraries.forEach((lib, index) => {
            const div = document.createElement('div');
            div.className = 'library-item';
            div.innerHTML = `
                <div>
                    <strong>${lib.name}</strong>
                    <span class="status-badge ${lib.active ? 'status-active' : 'status-inactive'}">
                        ${lib.active ? 'Active' : 'Inactive'}
                    </span>
                </div>
                <div class="lib-actions">
                    <button class="btn btn-secondary btn-sm" onclick="toggleLibrary(${index})">
                        ${lib.active ? 'Disable' : 'Enable'}
                    </button>
                    <button class="btn btn-outline btn-sm" style="border-color: #ef4444; color: #ef4444;" onclick="removeLibrary(${index})">
                        Remove
                    </button>
                </div>
            `;
            librariesList.appendChild(div);
        });
    }

    window.toggleLibrary = (index) => {
        customLibraries[index].active = !customLibraries[index].active;
        saveLibraries();
    };

    window.removeLibrary = (index) => {
        if (confirm('Remove this library and all its quiz sets?')) {
            customLibraries.splice(index, 1);
            saveLibraries();
        }
    };

    importInput.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onload = (event) => {
            try {
                let data = JSON.parse(event.target.result);
                
                // Flexible support: If it's just an array of questions, wrap it in a default QuizSet
                if (Array.isArray(data)) {
                    data = {
                        quizSets: [{
                            id: 'raw-' + Date.now(),
                            title: file.name,
                            subjects: ["Uncategorized"],
                            topics: ["Imported"],
                            difficulty: "Mixed",
                            libraryPath: "EMBEDDED",
                            embeddedQuestions: data,
                            filterSettings: { subjects: [], topics: [], difficulties: [], tags: [] }
                        }]
                    };
                }

                if (!data.quizSets || !Array.isArray(data.quizSets)) {
                    throw new Error('Invalid format: Missing quizSets array or raw questions array');
                }

                const newLib = {
                    name: file.name,
                    active: true,
                    data: data,
                    importDate: new Date().toISOString()
                };

                customLibraries.push(newLib);
                saveLibraries();
                alert('Library imported successfully!');
            } catch (err) {
                alert('Error parsing JSON: ' + err.message);
            }
        };
        reader.readAsText(file);
    });

    function renderQuizSets() {
        quizList.innerHTML = '';
        
        customLibraries.filter(lib => lib.active).forEach(lib => {
            lib.data.quizSets.forEach(set => {
                const card = createQuizCard(set, lib.name);
                quizList.appendChild(card);
            });
        });
    }

    function createQuizCard(set, libName) {
        const card = document.createElement('div');
        card.className = 'quiz-card';
        card.style.cursor = 'pointer';

        const subjectsText = (set.subjects || []).join(', ');
        const topicsText = (set.topics || []).join(', ');

        card.innerHTML = `
            <div style="font-size: 0.7rem; color: var(--accent-primary); margin-bottom: 0.5rem;">FROM: ${libName}</div>
            <h3>${set.title || 'Untitled Quiz'}</h3>
            <div class="quiz-info">
                <div class="info-item">
                    <span class="info-label">Subject:</span> ${subjectsText}
                </div>
                <div class="info-item">
                    <span class="info-label">Difficulty:</span> 
                    <span class="difficulty-badge">${set.difficulty || 'Unknown'}</span>
                </div>
            </div>
            <div class="tags-container">
                ${(set.tags || []).map(tag => `<span class="tag">${tag}</span>`).join('')}
            </div>
        `;

        card.addEventListener('click', () => {
            // Store the embedded questions in session storage so quiz.js can find them
            if (set.libraryPath === 'EMBEDDED') {
                sessionStorage.setItem('temp_custom_questions', JSON.stringify(set.embeddedQuestions));
            }
            window.location.href = `quiz.html?id=${set.id}&source=custom`;
        });

        return card;
    }

    renderLibraries();
    renderQuizSets();
});
