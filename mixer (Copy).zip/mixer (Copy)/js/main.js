document.addEventListener('DOMContentLoaded', () => {
    // Smooth scrolling for navigation links
    const navLinks = document.querySelectorAll('.nav-links a');
    
    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            const href = link.getAttribute('href');
            
            // If it's an internal link
            if (href.startsWith('#')) {
                e.preventDefault();
                const targetId = href.substring(1);
                const targetElement = document.getElementById(targetId);
                
                if (targetElement) {
                    window.scrollTo({
                        top: targetElement.offsetTop - 80, // Adjust for sticky header
                        behavior: 'smooth'
                    });
                    
                    // Update active class
                    navLinks.forEach(l => l.classList.remove('active'));
                    link.classList.add('active');
                } else if (href === '#') {
                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });

    // Button event listeners
    const personalizedBtn = document.getElementById('personalized-quiz');
    const customBtn = document.getElementById('custom-quiz');

    personalizedBtn.addEventListener('click', () => {
        console.log('Personalized Quiz initiated: Opening filter settings...');
        // Future: Open modal or navigation to filter page
    });

    customBtn.addEventListener('click', () => {
        console.log('Custom Quiz initiated: Ready for JSON import...');
        // Future: Trigger file input or navigation to import page
    });

    // Navbar scroll effect
    const navbar = document.querySelector('.navbar');
    window.addEventListener('scroll', () => {
        if (window.scrollY > 50) {
            navbar.style.boxShadow = '0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)';
            navbar.style.borderColor = 'rgba(255, 255, 255, 0.1)';
        } else {
            navbar.style.boxShadow = 'none';
            navbar.style.borderColor = 'rgba(255, 255, 255, 0.05)';
        }
    });
});
